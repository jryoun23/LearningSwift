//
//  ViewController.swift
//  Lab 7
//
//  Created by Joseph Young on 3/26/21.
//

import UIKit
import MapKit

class ViewController: UIViewController
{
    var newEarthquakeData = [earthquakeData]()
    {
        didSet{
            resultsField.text = "";
                    for i in 0..<newEarthquakeData.count
                    {
                        resultsField.text?.append("dateTime: " + newEarthquakeData[i].datetime + "\t magnitude" + String(newEarthquakeData[i].magnitude) + "\n")
                        if i == 10
                        {
                            break
                        }
                    }
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let url = "http://api.geonames.org/earthquakesJSON?north=44.1&south=-9.9&east=-22.4&west=55.2&username=jryoun23"
        getEarthquakeData(from: url)
        // Do any additional setup after loading the view.
    }
    
    func getEarthquakeData(from url:String)
    {
        let task = URLSession.shared.dataTask(with: URL(string : url)!, completionHandler: {data, Response, error in
            guard let data = data, error == nil else
            {
                print("Soemthing went wrong in data ")
                return
            }
            var result:earthquakeResponse?
            do{
                result = try JSONDecoder().decode(earthquakeResponse.self, from: data)
            }
            catch{
                print("The daat doesnt match what we were expecting")
            }
            guard let json = result else
            {
                return
            }
            
            DispatchQueue.main.async {
                self.newEarthquakeData = json.earthquakes
            }
            
        })
        task.resume()
    }
    
    
    @IBOutlet weak var addressField: UITextField!
    @IBOutlet weak var resultsField: UILabel!
    
    let url = "http://api.geonames.org/earthquakesJSON?north=44.1&south=-9.9&east=-22.4&west=55.2&username=jryoun23"
  
    @IBAction func search(_ sender: Any) {
        if let addy = addressField.text, !addy.isEmpty
        {
            let geoCoder = CLGeocoder();
            CLGeocoder().geocodeAddressString(addy , completionHandler: {(placemarks, error) in
                
                    if error != nil
                    {
                        print("geocode failed: \(error!.localizedDescription)")
                    }
                    else if(placemarks!.count > 0)
                    {
                        let placemark = placemarks![0]
                        let location = placemark.location
                        let coordiantes = location!.coordinate
                        self.resultsField.text = "";
                        self.resultsField.text?.append(String(coordiantes.longitude) + "\n");
                        self.resultsField.text?.append(String(coordiantes.latitude))
                        var north = coordiantes.latitude + 10
                        var south = coordiantes.latitude - 10
                        var east = coordiantes.longitude - 10
                        var west = coordiantes.longitude + 10
                        var newUrl = "http://api.geonames.org/earthquakesJSON?north=\(Float(north))&south=\(Float(south))&east=\(Float(east))&west=\(Float(west))&username=jryoun23"
                        print(newUrl)
                        self.getEarthquakeData(from: newUrl)
                    }
            })
            
        }
        else
        {
            resultsField.text = "Need an address to lookup";
            return
        }
    
    }
}

struct earthquakeResponse: Codable
{
    let earthquakes: [earthquakeData]
}

struct earthquakeData : Codable
{
    let datetime :String
    let depth:Double
    let lng :Double
    let src:String
    let eqid:String
    let magnitude:Float
    let lat : Double
}

/*
 {"earthquakes":
 [
    {"datetime":"2011-03-11 04:46:23","depth":24.4,"lng":142.369,"src":"us","eqid":"c0001xgp","magnitude":8.8,"lat":38.322},
    {"datetime":"2012-04-11 06:38:37","depth":22.9,"lng":93.0632,"src":"us","eqid":"c000905e","magnitude":8.6,"lat":2.311},
    {"datetime":"2007-09-12 09:10:26","depth":30,"lng":101.3815,"src":"us","eqid":"2007hear","magnitude":8.4,"lat":-4.5172},
    {"datetime":"2012-04-11 08:43:09","depth":16.4,"lng":92.4522,"src":"us","eqid":"c00090da","magnitude":8.2,"lat":0.7731},
    {"datetime":"2019-05-26 07:41:44","depth":109.88,"lng":-75.2975,"src":"us","eqid":"us60003sc0","magnitude":8,"lat":-5.796},
    {"datetime":"2007-04-01 18:39:56","depth":10,"lng":156.9567,"src":"us","eqid":"2007aqbk","magnitude":8,"lat":-8.4528},
    {"datetime":"2017-01-22 04:32:20","depth":136,"lng":155.1224,"src":"us","eqid":"us10007uph","magnitude":7.9,"lat":-6.2137},
    {"datetime":"2015-04-25 06:13:40","depth":15,"lng":84.6493,"src":"us","eqid":"us20002926","magnitude":7.9,"lat":28.1306},
    {"datetime":"2016-12-17 11:00:30","depth":103.19,"lng":153.4495,"src":"us","eqid":"us200081v8","magnitude":7.9,"lat":-4.5091},
    {"datetime":"2007-09-12 21:49:01","depth":10,"lng":100.9638,"src":"us","eqid":"2007hec6","magnitude":7.8,"lat":-2.5265}
 ]
 
 }
 
 
 
 */
