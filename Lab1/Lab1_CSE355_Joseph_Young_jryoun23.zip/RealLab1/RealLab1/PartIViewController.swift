//
//  PartIViewController.swift
//  RealLab1
//
//  Created by Joseph Young on 1/24/21.
//

import UIKit

class PartIViewController: UIViewController {

    
    var height:Double?
    var weight:Double?
    var BMI:Double?
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var heightText: UITextField!
    @IBOutlet weak var weightText: UITextField!
    @IBAction func calculateButton(_ sender: Any) {
        height = Double (heightText.text!)
        weight = Double (weightText.text!)
        BMI = (weight!/(height!*height!))*703
        bmiLabel.text = String(Float(BMI!))
        
        switch BMI!{
        case ..<18:
            finalMessage.text = "You are underweight"
            finalMessage.textColor = UIColor.blue
        case 18..<25:
            finalMessage.text = "You have a normal BMI"
            finalMessage.textColor = UIColor.green
        case 25..<30:
            finalMessage.text = "You are pre-obese"
            finalMessage.textColor = UIColor.purple
        case 30...:
            finalMessage.text = "You are obese"
            finalMessage.textColor = UIColor.red
        default:
            finalMessage.text = "You defy the laws of physics"
            finalMessage.textColor = UIColor.systemPink
            
        }
        
        }
    @IBOutlet weak var finalMessage: UILabel!
    @IBOutlet weak var bmiLabel: UILabel!
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
