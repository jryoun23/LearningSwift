//
//  PartIIViewController.swift
//  RealLab1
//
//  Created by Joseph Young on 1/24/21.
//

import UIKit

class PartIIViewController: UIViewController {

    @IBOutlet weak var weightVal: UILabel!
    @IBOutlet weak var heightVal: UILabel!
    @IBOutlet weak var finalMessage: UILabel!
    @IBOutlet weak var heightSlider: UISlider!
    @IBOutlet weak var weightSlider: UISlider!
    @IBOutlet weak var bmiLabel: UILabel!
    @IBAction func heightSlider(_ sender: Any) {
        var height:Float = heightSlider.value
        var weight:Float = weightSlider.value
        var BMI:Float = ((weight/(height*height))*703)
        heightVal.text = String(height)
        weightVal.text = String(weight)
        bmiLabel.text = String(BMI)
        
        switch BMI{
        case ..<18:
            finalMessage.text = "You are underweight"
            finalMessage.textColor = UIColor.blue
        case 18..<25:
            finalMessage.text = "You have a normal BMI"
            finalMessage.textColor = UIColor.green
        case 25..<30:
            finalMessage.text = "You are pre-obese"
            finalMessage.textColor = UIColor.purple
        case 30...:
            finalMessage.text = "You are obese"
            finalMessage.textColor = UIColor.red
        default:
            finalMessage.text = "You defy the laws of physics"
            finalMessage.textColor = UIColor.systemPink
            
        }
    }
    @IBAction func weightSlider(_ sender: Any) {
        var height:Float = heightSlider.value
        var weight:Float = weightSlider.value
        var BMI:Float = ((weight/(height*height))*703)
        heightVal.text = String(height)
        weightVal.text = String(weight)
        bmiLabel.text = String(BMI)
        
        switch BMI{
        case ..<18:
            finalMessage.text = "You are underweight"
            finalMessage.textColor = UIColor.blue
        case 18..<25:
            finalMessage.text = "You have a normal BMI"
            finalMessage.textColor = UIColor.green
        case 25..<30:
            finalMessage.text = "You are pre-obese"
            finalMessage.textColor = UIColor.purple
        case 30...:
            finalMessage.text = "You are obese"
            finalMessage.textColor = UIColor.red
        default:
            finalMessage.text = "You defy the laws of physics"
            finalMessage.textColor = UIColor.systemPink
            
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        heightSlider.value = 50
        weightSlider.value = 200
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
